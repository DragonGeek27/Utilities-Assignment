// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum AbuseReportType : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("OBJECT")]
    Object,

    [Description("USER")]
    User,

  }

}
