// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

namespace Oculus.Platform
{

  using Description = System.ComponentModel.DescriptionAttribute;

  public enum RoomJoinability : int
  {
    [Description("UNKNOWN")]
    Unknown,

    [Description("ARE_IN")]
    AreIn,

    [Description("ARE_KICKED")]
    AreKicked,

    [Description("CAN_JOIN")]
    CanJoin,

    [Description("IS_FULL")]
    IsFull,

    [Description("NO_VIEWER")]
    NoViewer,

    [Description("POLICY_PREVENTS")]
    PolicyPrevents,

  }

}
